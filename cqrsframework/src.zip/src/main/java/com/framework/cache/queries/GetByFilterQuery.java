package com.framework.cache.queries;

import com.framework.domain.core.filters.Filter;
import com.framework.services.Query;

public class GetByFilterQuery<T> extends Query<T> {

    private static final String name = "GetByFilterQuery";

    public GetByFilterQuery(Filter<T> filter) {
        super(name, filter);
    }
}
