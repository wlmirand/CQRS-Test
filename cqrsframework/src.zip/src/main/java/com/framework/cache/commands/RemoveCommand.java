package com.framework.cache.commands;

import com.framework.services.Command;

public class RemoveCommand<T> extends Command<T> {

    private static final String name = "RemoveCommand";

    public RemoveCommand(String name, T message) {
        super(name, message);
    }
}
