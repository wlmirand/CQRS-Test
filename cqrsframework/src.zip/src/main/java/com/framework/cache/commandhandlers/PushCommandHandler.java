package com.framework.cache.commandhandlers;

import com.framework.data.repositories.IRepository;
import com.framework.domain.Doctor;
import com.framework.services.CommandHandler;

public class PushCommandHandler<T> extends CommandHandler<T> {

    @Override
    protected void execute(IRepository<T> repository, T entity) {
        repository.save(entity);
    }
}
