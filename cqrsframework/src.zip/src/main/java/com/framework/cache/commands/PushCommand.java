package com.framework.cache.commands;

import com.framework.services.Command;

public class PushCommand<T> extends Command<T> {

    private static final String name = "PushCommand";

    public PushCommand(T message) {
        super(name, message);
    }
}
