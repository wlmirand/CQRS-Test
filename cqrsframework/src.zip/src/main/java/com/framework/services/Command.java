package com.framework.services;

public abstract class Command<T> implements ICommand {

    private T message;

    private String name;

    protected Command(String name, T message) {
        this.name = name;
        this.message = message;
    }

    @Override
    public String getName() {
        return name;
    }

    public T getMessage() {
        return message;
    }

}
