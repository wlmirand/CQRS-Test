package com.framework.services;

import java.util.List;
import java.util.Map;

/**
 * O CacheService ira processar Commands e Queries
 * Então ele precisa passar os Commands para os respectivos Handlers
 */
public abstract class Service<T> implements IService<T> {

    /**
     * Deve existir um Handler que sabe processar cada tipo de comando
     */
    private Map<String, ICommandHandler<Command>> mapCommands;

    /**
     * Outro Handler para Queries??
     */
    private Map<String, IQueryHandler<Query, T>> mapQueries;

    //@Inject   escrever as regras para injetar apenas os comandos relacionados ao CacheService
    protected Service(
            Map<String, ICommandHandler<Command>> mapCommands,
            Map<String, IQueryHandler<Query, T>> mapQueries) {
        this.mapCommands = mapCommands;
        this.mapQueries = mapQueries;
    }

    /**
     * Envia um Command para o seu Handler
     * @param command
     */
    @Override
    public void processCommand(Command command) {
        ICommandHandler handler = mapCommands.get(command.getName());
        handler.handle(command);
    }

    /**
     * Envia um Query para o seu Handler
     * @param query
     */
    @Override
    public List<T> processQuery(Query query) {
        IQueryHandler handler = mapQueries.get(query.getName());
        return handler.handle(query);
    }
}
