package com.framework.services;

public interface IQuery {
    String getName();
}
