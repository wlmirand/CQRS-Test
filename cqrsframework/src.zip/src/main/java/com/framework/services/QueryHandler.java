package com.framework.services;

import com.framework.data.repositories.IRepository;

public abstract class QueryHandler<IN extends IQuery, OUT> implements IQueryHandler<IN, OUT> {

    protected IRepository<OUT> repository;
}
