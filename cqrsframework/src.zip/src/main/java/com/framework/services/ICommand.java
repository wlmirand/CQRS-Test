package com.framework.services;

/**
 * Definicao do contrato dos comandos
 */
public interface ICommand {
    String getName();
}
