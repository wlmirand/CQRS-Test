package com.framework.services;

import com.framework.domain.core.filters.Filter;

public abstract class Query<T> implements IQuery {

    private Filter<T> filter;

    private String name;

    protected Query(String name, Filter<T> filter) {
        this.name = name;
        this.filter = filter;
    }

    @Override
    public String getName() {
        return name;
    }

    public Filter<T> getFilter() {
        return filter;
    }
}
