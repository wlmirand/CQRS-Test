package com.framework.domain;

public class BolaDeBerlim {
}
