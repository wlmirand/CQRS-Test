package com.framework.domain.patients;

public class Patient {

    int age;
}
