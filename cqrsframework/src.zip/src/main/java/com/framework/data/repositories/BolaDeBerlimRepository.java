package com.framework.data.repositories;

import com.framework.domain.BolaDeBerlim;
import com.framework.domain.core.filters.Filter;

import java.util.List;

public class BolaDeBerlimRepository implements IRepository<BolaDeBerlim> {

    public void save(BolaDeBerlim item) {
        //item.
    }

    @Override
    public List<BolaDeBerlim> find(Filter<BolaDeBerlim> filter) {
        return null;
    }

}
