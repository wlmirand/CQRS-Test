package com.framework.data.repositories;

import com.framework.domain.core.filters.Filter;
import com.framework.domain.patients.Patient;

import java.util.List;

public class PatientRepository implements IRepository<Patient> {

    public void save(Patient item) {
        //item.
    }

    @Override
    public List<Patient> find(Filter<Patient> filter) {


        return null;
    }


}
